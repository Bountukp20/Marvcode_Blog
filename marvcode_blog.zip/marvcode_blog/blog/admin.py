from django.contrib import admin

# Register your models here.
from .models import *

admin.site.register(Html)
admin.site.register(HtmlLikes)
admin.site.register(Random)
admin.site.register(Css)
admin.site.register(JavaScript)
admin.site.register(BootStrap)
admin.site.register(Python)
admin.site.register(Django)
admin.site.register(React)
admin.site.register(Comments)
admin.site.register(HtmlComment)
admin.site.register(ReactLikes)
admin.site.register(CssLikes)
admin.site.register(JavaScriptLikes)
admin.site.register(RandomLikes)
admin.site.register(BootStrapLikes)
admin.site.register(PythonLikes)
admin.site.register(DjangoLikes)
admin.site.register(BootStrapComment)
admin.site.register(PythonComment)
admin.site.register(DjangoComment)
admin.site.register(ReactComment)
admin.site.register(CssComment)
admin.site.register(RandomComment)
admin.site.register(JavaScriptComment)


