from django.db import models
from django.conf import settings
from django.contrib.auth.models import User
from datetime import datetime
import uuid, random
from django.utils import timezone
from django.urls import reverse



# Create your models here.
class Html(models.Model):
    id = models.IntegerField(default=1, primary_key=True, editable=True, unique=True)
    title = models.CharField(max_length=300)
    body = models.TextField()
    link = models.CharField(max_length=300)
    link_two = models.CharField(max_length=300)
    link_three = models.CharField(max_length=300)
    link_four = models.CharField(max_length=300)
    link_five = models.CharField(max_length=300)
    link_six = models.CharField(max_length=300)
    like_num = models.IntegerField(default=0)
    user = models.ForeignKey(User,on_delete=models.CASCADE,null=True, blank=True)
    
    class Meta:
        verbose_name_plural = "Html"
    def __str__(self):
            return self.title
    def get_absolute_url(self):
        return reverse("all_html", args=[self.id])

class HtmlComment(models.Model):   
    username = models.CharField(max_length=300)
    email = models.CharField(max_length=300)
    topic = models.CharField(max_length=300)
    comment = models.CharField(max_length=300)
    def __str__(self):
        return self.username;
   

class HtmlLikes(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE,null=True, blank=True)
    id = models.IntegerField(default=1, primary_key=True, editable=True, unique=True)
    like_num = models.IntegerField(default=0)
    class Meta:
        verbose_name_plural = "Htmllikes"

   
class Random(models.Model):
    title = models.CharField(max_length=300)
    body = models.TextField()
    link = models.CharField(max_length=300)
    link_two = models.CharField(max_length=300)
    link_three = models.CharField(max_length=300)
    link_four = models.CharField(max_length=300)
    link_five = models.CharField(max_length=300)
    link_six = models.CharField(max_length=300)
    class Meta:
        verbose_name_plural = "Random"
    def __str__(self):
            return self.title
   

class RandomLikes(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE,null=True, blank=True)
    id = models.IntegerField(default=1, primary_key=True, editable=True, unique=True)
    like_num = models.IntegerField(default=0)
    class Meta:
        verbose_name_plural = "Randomlikes"

      
class RandomComment(models.Model):   
    username = models.CharField(max_length=300)
    email = models.CharField(max_length=300)
    topic = models.CharField(max_length=300)
    comment = models.CharField(max_length=300)
    def __str__(self):
        return self.username;

class Css(models.Model):
    title = models.CharField(max_length=300)
    body = models.TextField()
    link = models.CharField(max_length=300)
    link_two = models.CharField(max_length=300)
    link_three = models.CharField(max_length=300)
    link_four = models.CharField(max_length=300)
    link_five = models.CharField(max_length=300)
    link_six = models.CharField(max_length=300)
    class Meta:
        verbose_name_plural = "Css"
    def __str__(self):
            return self.title
   
class CssComment(models.Model):   
    username = models.CharField(max_length=300)
    email = models.CharField(max_length=300)
    topic = models.CharField(max_length=300)
    comment = models.CharField(max_length=300)
    def __str__(self):
        return self.username;
   

class CssLikes(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE,null=True, blank=True)
    id = models.IntegerField(default=1, primary_key=True, editable=True, unique=True)
    like_num = models.IntegerField(default=0)
    class Meta:
        verbose_name_plural = "Csslikes"

   
class JavaScript(models.Model):
    title = models.CharField(max_length=300)
    body = models.TextField()
    link = models.CharField(max_length=300)
    link_two = models.CharField(max_length=300)
    link_three = models.CharField(max_length=300)
    link_four = models.CharField(max_length=300)
    link_five = models.CharField(max_length=300)
    link_six = models.CharField(max_length=300)
    class Meta:
        verbose_name_plural = "JavaScript"
    def __str__(self):
            return self.title
   
class JavaScriptComment(models.Model):   
    username = models.CharField(max_length=300)
    email = models.CharField(max_length=300)
    topic = models.CharField(max_length=300)
    comment = models.CharField(max_length=300)
    def __str__(self):
        return self.username;
   

class JavaScriptLikes(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE,null=True, blank=True)
    id = models.IntegerField(default=1, primary_key=True, editable=True, unique=True)
    like_num = models.IntegerField(default=0)
    class Meta:
        verbose_name_plural = "JavaScriptlikes"

   
class BootStrap(models.Model):
    title = models.CharField(max_length=300)
    body = models.TextField()
    link = models.CharField(max_length=300)
    link_two = models.CharField(max_length=300)
    link_three = models.CharField(max_length=300)
    link_four = models.CharField(max_length=300)
    link_five = models.CharField(max_length=300)
    link_six = models.CharField(max_length=300)
    class Meta:
        verbose_name_plural = "BootStrap"
    def __str__(self):
            return self.title
   
class BootStrapComment(models.Model):   
    username = models.CharField(max_length=300)
    email = models.CharField(max_length=300)
    topic = models.CharField(max_length=300)
    comment = models.CharField(max_length=300)
    def __str__(self):
        return self.username;
   

class BootStrapLikes(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE,null=True, blank=True)
    id = models.IntegerField(default=1, primary_key=True, editable=True, unique=True)
    like_num = models.IntegerField(default=0)
    class Meta:
        verbose_name_plural = "BootStraplikes"

   
class Python(models.Model):
    title = models.CharField(max_length=300)
    body = models.TextField()
    link = models.CharField(max_length=300)
    link_two = models.CharField(max_length=300)
    link_three = models.CharField(max_length=300)
    link_four = models.CharField(max_length=300)
    link_five = models.CharField(max_length=300)
    link_six = models.CharField(max_length=300)
    class Meta:
        verbose_name_plural = "Python"
    def __str__(self):
            return self.title
   

class PythonLikes(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE,null=True, blank=True)
    id = models.IntegerField(default=1, primary_key=True, editable=True, unique=True)
    like_num = models.IntegerField(default=0)
    class Meta:
        verbose_name_plural = "Pythonlikes"

   
class PythonComment(models.Model):   
    username = models.CharField(max_length=300)
    email = models.CharField(max_length=300)
    topic = models.CharField(max_length=300)
    comment = models.CharField(max_length=300)
    def __str__(self):
        return self.username;

class Django(models.Model):
    title = models.CharField(max_length=300)
    body = models.TextField()
    link = models.CharField(max_length=300)
    link_two = models.CharField(max_length=300)
    link_three = models.CharField(max_length=300)
    link_four = models.CharField(max_length=300)
    link_five = models.CharField(max_length=300)
    link_six = models.CharField(max_length=300)
    class Meta:
        verbose_name_plural = "Django"
    def __str__(self):
            return self.title
   

class DjangoLikes(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE,null=True, blank=True)
    id = models.IntegerField(default=1, primary_key=True, editable=True, unique=True)
    like_num = models.IntegerField(default=0)
    class Meta:
        verbose_name_plural = "Djangolikes"

   
class DjangoComment(models.Model):   
    username = models.CharField(max_length=300)
    email = models.CharField(max_length=300)
    topic = models.CharField(max_length=300)
    comment = models.CharField(max_length=300)
    def __str__(self):
        return self.username;

class React(models.Model):
    title = models.CharField(max_length=300)
    body = models.TextField()
    link = models.CharField(max_length=300)
    link_two = models.CharField(max_length=300)
    link_three = models.CharField(max_length=300)
    link_four = models.CharField(max_length=300)
    link_five = models.CharField(max_length=300)
    link_six = models.CharField(max_length=300)
    class Meta:
        verbose_name_plural = "React"
    def __str__(self):
            return self.title
   
class ReactComment(models.Model):   
    username = models.CharField(max_length=300)
    email = models.CharField(max_length=300)
    topic = models.CharField(max_length=300)
    comment = models.CharField(max_length=300)
    def __str__(self):
        return self.username;

class ReactLikes(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE,null=True, blank=True)
    like_num = models.IntegerField(default=0)
    class Meta:
        verbose_name_plural = "reactlikes"

class Comments(models.Model):
    name = models.CharField(max_length=30)
    comment = models.TextField()
    def __str__(self):
        return self.name
    class Meta:
        verbose_name_plural = "comments"


























